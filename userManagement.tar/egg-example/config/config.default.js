/* eslint valid-jsdoc: "off" */

'use strict';

/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {};

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1564551409545_7660';

  // add your middleware config here
  config.middleware = [];

  // add your user config here
  const userConfig = {
    // myAppName: 'egg',
  };
//添加sequelize插件配置
  config.sequelize = {
    dialect: 'mysql',
    host: 'localhost',
    port: 3306,
    username: 'root',
    password: 'root',
    database: 'usertest',
  };
  
// 添加 view 配置
  config.view = {
    defaultViewEngine: 'nunjucks',
    cache: true,
    mapping: {
    '.tpl': 'nunjucks',
    }
  };

  //关闭egg安全系统
  config.security = {
    csrf: {
      enable: false
    }
 };
 //关闭将日志打印到控制台上
  config.logger = {
    disableConsoleAfterReady: false
  }; 

  return config;
};