'use strict';

//开启nunjucks插件
exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks'
};

//eggjs来操作数据库的ORM框架
exports.sequelize = {
  enable: true,
  package: 'egg-sequelize',
};