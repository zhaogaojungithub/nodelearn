const service = require('egg').Service;
class UserService extends service{
    //查询所有用户信息
    async getUserList() {
        this.ctx.logger.info('service---------获取用户列表.........');
        var data =await this.ctx.model.User.findAll();
        return data;
    }

    //添加用户信息
    async addUser(param) {
        var ctx = this.ctx;
        ctx.logger.info('service--------添加用户信息.........');
        if(param.name == undefined){
            return 0;
        }else{
            //返回刚刚添加的对象的信息
            var user = await ctx.model.User.create(param);
            return user.id;
        }
    }

    //删除用户信息
    async delUser(param) {
        var ctx = this.ctx;
        ctx.logger.info('service--------删除用户信息.........');

        if(param.id == undefined){
            ctx.logger.info('需要删除的用户的id不存在........');
            return 0;
        }else{
            var user = await ctx.model.User.findByPk(param.id);
            if(!user){
                ctx.logger.info('该用户不存在..............');
                return 0;
            }else{
                var data = await user.destroy();
                ctx.logger.info('删除结果:'+data.id);
                return data.id;
            }
        }
    }

    //修改用户信息
    async updateUser(param) {
        var ctx = this.ctx;
        ctx.logger.info('service--------修改用户信息.........');

        if(param.id == undefined){
            ctx.logger.info('需要修改的用户的id不存在..........');
            return 0;
        }else{
            var user = await ctx.model.User.findByPk(param.id);
            if(!user){
                ctx.logger.info('该用户不存在........')
                return 0;
            }else{
                var data = await user.update(param);
                ctx.logger.info('修改结果:'+data.id);
                return data.id;
            }
        }
    }
}
module.exports = UserService;