module.exports = app => {
    const {STRING,INTEGER,DATE} = app.Sequelize;
    //注意，此处会自动将表名称处理成users,所以需要在第三个参数指明自己的数据库
    const User = app.model.define('user', {
        id: { type: INTEGER, primaryKey: true, autoIncrement: true },
        name: STRING,
        age: INTEGER,
        sex: INTEGER,
        address: STRING,
        created_at: DATE,
        updated_at: DATE
      },{tableName:'user'});
      return User;
}