const controller = require('egg').Controller;

class UserCtrl extends controller{

    //查询所有用户信息
    async listUser() {
        var ctx = this.ctx;
        ctx.logger.info('controller-----获取用户列表..........');
        var data = await this.ctx.service.user.getUserList();
        ctx.response.body = data;
    }

    //添加用户信息
    async addUser() {
        var ctx = this.ctx;
        ctx.logger.info('controller-------添加用户........');
        var param = ctx.request.query;
        var data = await ctx.service.user.addUser(param);
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        ctx.response.body = JSON.stringify(data);
    }
    
    //删除用户信息
    async delUser() {
        var ctx = this.ctx;
        ctx.logger.info('controller------删除用户信息........');
        var param = ctx.request.query;
        var data = await ctx.service.user.delUser(param);
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        ctx.response.body = JSON.stringify(data);

    }

    //修改用户信息
    async updateUser() {
        var ctx = this.ctx;
        ctx.logger.info('controller------修改用户信息........'); 
        var param = ctx.request.query;       
        var data = await ctx.service.user.updateUser(param);
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        ctx.response.body = JSON.stringify(data);
    }
}
module.exports = UserCtrl;