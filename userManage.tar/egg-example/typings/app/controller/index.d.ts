// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportNews = require('../../../app/controller/news');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    news: ExportNews;
    user: ExportUser;
  }
}
