const controller = require('egg').Controller;
const http = require('http');

class UserCtrl extends controller{

    //查询所有用户信息
    async listUser() {
        var data = await this.ctx.service.user.getUserList();
        //await this.ctx.render('../view/list.tpl',[data]);
        this.ctx.response.body = data;
    }

    //添加用户信息
    async addUser() {
        console.log("添加用户.......");
        var data = await this.ctx.service.user.addUser();
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        this.ctx.response.body = JSON.stringify(data);
    }
    
    //删除用户信息
    async delUser() {
        console.log('删除用户信息.............');
        var data = await this.ctx.service.user.delUser();
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        this.ctx.response.body = JSON.stringify(data);

    }

    //修改用户信息
    async updateUser() {
        console.log('修改用户信息.............');
        var data = await this.ctx.service.user.updateUser();
        if(data > 0){
            data = {
                msg:'success',
                success:true
            }
        }else{
            data = {
                msg:'faild',
                success:false
            }
        }
        this.ctx.response.body = JSON.stringify(data);
    }
}
module.exports = UserCtrl;