const service = require('egg').Service;
class UserService extends service{
    //查询所有用户信息
    async getUserList() {

        const data = await this.app.mysql.select('user');
        return data;
    }

    //添加用户信息
    async addUser() {
        var param = this.ctx.request.query;
        //var data = await this.app.mysql.insert('user',param);
        if(param.name == undefined){
            return 0;
        }else{
             //加入事务管理
            var data = await this.app.mysql.beginTransactionScope(async coon =>{
                return await coon.insert('user',param);
            },this.ctx);
            return data.affectedRows;
        }
    }

    //删除用户信息
    async delUser() {
        var param = this.ctx.request.query;
        if(param.id == undefined){
            console.log('数据为空........');
            return 0;
        }else{
            var data = await this.app.mysql.beginTransactionScope(async coon =>{
                return await coon.delete('user',param);
            },this.ctx);
            console.log('*********'+data.affectedRows);
            return data.affectedRows;
        }
    }

    //修改用户信息
    async updateUser() {
        var param = this.ctx.request.query;
        if(param.id == undefined){
            console.log('数据为空........');
            return 0;
        }else{
            var data = await this.app.mysql.beginTransactionScope(async coon =>{
                return await coon.update('user',param);
            },this.ctx);
            return data.affectedRows;
        }
    }
}
module.exports = UserService;