'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  router.get('/getUsers',controller.user.listUser);
  router.post('/addUser',controller.user.addUser);
  router.delete('/delUser',controller.user.delUser);
  router.post('/updateUser',controller.user.updateUser);  
};
