'use strict';

//开启nunjucks插件
exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks'
};

//开启MySQL插件
exports.mysql = {
  enable: true,
  package: 'egg-mysql',
};
